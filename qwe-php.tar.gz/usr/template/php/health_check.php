<?php
echo '1';